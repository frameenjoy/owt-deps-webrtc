DEPS = [
    'recipe_engine/json',
    'recipe_engine/path',
    'recipe_engine/python',
    'recipe_engine/raw_io',
    'recipe_engine/url',
]
