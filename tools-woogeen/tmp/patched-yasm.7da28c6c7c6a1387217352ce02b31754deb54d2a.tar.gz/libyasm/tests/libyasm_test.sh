#! /bin/sh
${srcdir}/out_test.sh libyasm_test libyasm/tests "libyasm" "-f bin" ""
exit $?
